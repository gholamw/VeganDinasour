---
name: Support
about: I need support with TableFilter
title: ''
labels: ''
assignees: ''

---

For usage and support questions, please check out resources below, you might find an answer:

- https://www.tablefilter.com/
- https://www.tablefilter.com/docs/
- https://www.tablefilter.com/examples.html
- https://github.com/koalyptus/TableFilter/wiki/
- https://github.com/koalyptus/TableFilter/issues?q=is%3Aissue+is%3Aclosed
- https://codepen.io/koalyptus/pens/public/

'use strict';

module.exports = require('./dist/tablefilter/tablefilter').TableFilter;
